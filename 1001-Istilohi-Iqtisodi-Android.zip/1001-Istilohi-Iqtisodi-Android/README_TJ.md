# 1001 Истилоҳи иқтисодӣ — Android / Google Play

Ин project HTML-и аслиро ба Android WebView табдил медиҳад ва барои сохтани APK/AAB дар Android Studio омода аст.

## Танзимоти асосӣ
- Application ID: `com.saidshohtech.ecoterm`
- Version: `1.0.0` (`versionCode 1`)
- minSdk: 23
- targetSdk / compileSdk: 36 (Android 16)
- Интернет: талаб намешавад ва дар WebView network requests баста шудаанд.
- HTML: `app/src/main/assets/index.html`
- JavaScript ва localStorage: фаъол
- TTS: функсияи талаффуз ба Android TextToSpeech пайваст шудааст.

## Чӣ тавр AAB созед
1. Android Studio-и навро насб кунед.
2. Folder-и project-ро бо **Open** кушоед.
3. Агар Android SDK 36 набошад: Tools → SDK Manager → Android 16 (API 36)-ро насб кунед.
4. Бигзор Gradle Sync анҷом шавад.
5. Барои санҷиш: Run ▶ ва телефон/эмуляторро интихоб кунед.
6. Барои Google Play: Build → Generate Signed App Bundle or APK → Android App Bundle.
7. **Create new**-ро зер карда upload keystore созед ва онро дар ҷои бехатар нигоҳ доред.
8. Release-ро интихоб кунед ва `.aab` созед.
9. AAB-ро ба Google Play Console → Release ворид кунед.

## Муҳим
`applicationId`-ро пеш аз нашри аввал интихоб кунед. Пас аз нашр дар Google Play онро иваз кардан мумкин нест (барномаи нав ҳисоб мешавад).

## Google Play assets, ки ҳоло ҳам лозим мешаванд
- 512×512 app icon (PNG)
- Feature graphic 1024×500
- Phone screenshots
- Short/Full description
- Privacy Policy (мувофиқи функсияҳо ва маълумоти ҷамъшаванда)
- Data safety, Content rating, Target audience

Project ҳоло permission-и INTERNET надорад ва маълумоти барнома локалӣ коркард мешавад.
