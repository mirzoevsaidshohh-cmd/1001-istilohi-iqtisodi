package com.saidshohtech.ecoterm;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.rgb(16, 47, 72));
        getWindow().setNavigationBarColor(Color.rgb(16, 47, 72));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 245, 247));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);

        // Keep app content clear of Android system bars on modern edge-to-edge devices.
        webView.setOnApplyWindowInsetsListener((v, insets) -> {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(0, bars.top, 0, bars.bottom);
            } else {
                v.setPadding(0, insets.getSystemWindowInsetTop(), 0, insets.getSystemWindowInsetBottom());
            }
            return insets;
        });

        setContentView(webView);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setBlockNetworkLoads(true);
        webView.getSettings().setSupportZoom(false);
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setDisplayZoomControls(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);

        if (android.os.Build.VERSION.SDK_INT >= 26) {
            webView.getSettings().setSafeBrowsingEnabled(true);
        }

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                return !url.startsWith("file:///android_asset/");
            }
        });

        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setLanguage(Locale.US);
            }
        });
        webView.addJavascriptInterface(new TtsBridge(), "AndroidTTS");

        webView.loadUrl("file:///android_asset/index.html");
    }

    public final class TtsBridge {
        @JavascriptInterface
        public void speak(String text, String languageTag, float rate) {
            if (!ttsReady || text == null || text.trim().isEmpty()) return;
            runOnUiThread(() -> {
                Locale locale = Locale.forLanguageTag(languageTag == null ? "en-US" : languageTag);
                tts.setLanguage(locale);
                tts.setSpeechRate(Math.max(0.5f, Math.min(rate, 1.5f)));
                tts.stop();
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "term-pronunciation");
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }
        String js = "(function(){try{" +
                "if(typeof S!=='undefined'&&S.page&&S.page!=='home'&&typeof go==='function'){" +
                "go(S.prev||'home');return 'handled';}" +
                "return 'exit';}catch(e){return 'exit';}})();";
        webView.evaluateJavascript(js, value -> {
            if (value == null || value.contains("exit")) {
                MainActivity.super.onBackPressed();
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidTTS");
            webView.destroy();
        }
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }
}
